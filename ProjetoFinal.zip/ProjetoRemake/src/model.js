class Register{
    constructor(idRegister, name, email, password, birth){
        this.idRegister = idRegister;
        this.name = name;
        this.email = email;
        this.password = password;
        this.birth = birth;
    }
}
export default new Register();